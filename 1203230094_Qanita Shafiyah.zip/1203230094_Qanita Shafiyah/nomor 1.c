#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int nilaiKartu(char kartu[]) {
    switch(kartu[0]) {
        case 'J': 
            return 11;
        case 'Q': 
            return 12;
        case 'K': 
            return 13;
        default : return atoi(kartu); // Mengkonversi string ke integer
    }
}

int main() {
    int jumlahAngka;
    printf("Masukkan jumlah kartu: ");
    scanf("%d", &jumlahAngka); // Membaca jumlah kartu

    char card[jumlahAngka][3]; 
    for(int i = 0; i < jumlahAngka; i++) {
        scanf("%s", card[i]); // Membaca nilai kartu
    }

    int langkahPertukaran = 0;
    for(int i = 0; i < jumlahAngka - 1; i++) {
        int minIndex = i;
        for(int j = i+1; j < jumlahAngka; j++) {
           
            if(nilaiKartu(card[j]) < nilaiKartu(card[minIndex])) {
                minIndex = j;
            }
        }
        if(minIndex != i) {
            // Pertukaran posisi kartu
            char temp[3];
            strcpy(temp, card[i]);
            strcpy(card[i], card[minIndex]);
            strcpy(card[minIndex], temp);
            langkahPertukaran++;

            printf("\nPertukaran %d: ", langkahPertukaran);
            for (int K = 0; K < jumlahAngka; K++) {
                printf("%s ", card[K]);
            }
        }
    }

    printf("\nJumlah langkah pertukaran: %d\n", langkahPertukaran);
    return 0;
}
