#include <stdio.h>

int catur(int x, int y) {
    return (x >= 0 && x < 8 && y >= 0 && y < 8);
}

void koboImaginaryChess(int i, int j, int size, int *papanCatur) {
    int movesX[] = {2, 1, -1, -2, -2, -1, 1, 2};
    int movesY[] = {1, 2, 2, 1, -1, -2, -2, -1};

    for (int k = 0; k < 8; k++) {
        int nextX = i + movesX[k];
        int nextY = j + movesY[k];
        if (catur(nextX, nextY)) {
            *(papanCatur + nextX * size + nextY) = 1; 
        }
    }
}

int main() {
    int i, j;
    scanf("%d %d", &i, &j);

    int uk = 8; 
    int papanCatur[uk][uk]; 
    for (int x = 0; x < uk; x++) {
        for (int y = 0; y < uk; y++) {
            papanCatur[x][y] = 0;
        }
    }

    koboImaginaryChess(i, j, uk, (int *)papanCatur); 
    for (int x = 0; x < uk; x++) {
        for (int y = 0; y < uk; y++) {
            printf("%d ", papanCatur[x][y]);
        }
        printf("\n");
    }

    return 0;
}